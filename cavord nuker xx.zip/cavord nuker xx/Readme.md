# cavord nuker xx

* This is a mini tool - small in size but fully equipped with all the necessary features to nuke a server.
* A nuke tool built entirely in Python, designed to execute commands quickly.

## ┃Features

- [x] Change name.
- [x] Delete channels.
- [x] Create channels.
- [x] Webhook spam.
- [x] Massban.

## ┃ Tutorial

1. Download the `.zip` from this repo and extract it.  
2. Run the `.exe` file.  
3. Enter your bot token and the guild ID you want to nuke and use.

* **Note:** `Avoid using the webhook spam feature excessively.`

## ┃ Preview

![Preview](https://i.postimg.cc/GhrfDdYq/cavord-nuker-preview.png)


> `Discord`: https://discord.gg/RkWXSNF6Q8

> `Social`: https://guns.lol/cavord